#Change Log
All notable changes to this project will be documented in this file.

## [0.0.1] - 2015-02-04
### Added
- Sidebar.php added for template support. [@tahaalibra]
- New method is added for adding inline css and javascript into the view. [@tahaalibra]

### Modified
- New Improved template system, that can handle header, sidebar, footer and main area. [@tahaalibra]

## [0.0.1] - 2015-02-03
### Added
- This CHANGELOG file to hopefully serve as an evolving example of a standardized project CHANGELOG. [@tahaalibra]
- Test Extention is created for testing purpose. [@tahaalibra]

### Bugfix
- Auth extention is modfied to become more secure and easy to use. [@tahaalibra]
- checks.php checks if website can be loaded only in https protocol. [@tahaalibra]

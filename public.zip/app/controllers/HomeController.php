<?php

class HomeController extends Controller
{

    public function home()
    {
      
    }
}

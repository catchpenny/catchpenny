<?php

class Error_404Controller
{

    public function __construct()
    {
        echo "Invalid url. Page does not exists";
    }
}

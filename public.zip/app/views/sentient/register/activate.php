<div id="main">
    ${{activateMessage}}
</div>

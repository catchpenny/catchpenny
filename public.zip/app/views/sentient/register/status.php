<div id="main">
    ${{statusMessage}}
</div>

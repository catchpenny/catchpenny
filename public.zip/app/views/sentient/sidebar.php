
<div id="sidebar">
  <h1>Sidebar Area</h1>
</div>

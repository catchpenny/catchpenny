<html>
<head>
    <meta charset="UTF-8">
    <title>CatchPenny Project</title>
    <link rel="stylesheet" href="/catchpenny/css/main.css">
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

<div id="header">
<h1>CatchPenny Project</h1>
</div>

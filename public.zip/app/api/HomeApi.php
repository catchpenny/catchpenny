<?php

class HomeApi extends Api
{
    
public function Home()
 {
    echo $this->method;
 }   
}
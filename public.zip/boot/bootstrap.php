<?php
/*
 * Bootfile:
 * Load Essential website files
 * 
 */


//Load Configaration file
require_once ROOT.DS.'boot'.DS.'config.php';

//Load Initialization process
require_once ROOT.DS.'boot'.DS.'init.php';



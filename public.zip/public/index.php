<?php
/*
 * Index page
 * 
 */


//Define Directory Separator
define('DS', DIRECTORY_SEPARATOR);

//Define Root Directory Path
define('ROOT', dirname(dirname(__FILE__)));

//Call Bootstrap
require_once ROOT.DS.'boot'.DS.'bootstrap.php';

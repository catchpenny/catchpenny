<?php

class Upload
{
    public static function profilephoto()
    {
      
    }
}
